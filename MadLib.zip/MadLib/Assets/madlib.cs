﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class madlib : MonoBehaviour
{
    public string story = "Yesterday, [person] " +
        "and I went to the park. On our way to the [adjective] park" +
        ", we saw a [adjective] [noun] on a bike. We also saw big [adjective] balloons" +
        "tied to a [noun]. Once we got to the [adjective] park. It started to " +
        "[verb] and [verb]. [person] and I [verb] all the way home. Tomorrow " +
        "we will try to go to the [adjective] park again and hope it doesn't [verb].";
    public Text word;
    public InputField input;
    List<string> s = new List<string>();//story list
    List<string> w = new List<string>();//noun, verb list
    List<string> inputed = new List<string>();//inputed words
    public string Finish1;
    public string Finish = "";
    public int count = 0;
    private bool state = false;
    private void Start()
    {
        if (Input.GetKeyDown("return"))
        {
            word.text = "Welcome to MadLib";
            if (input.text.ToLower() == "start")
            {
                SSStart();
                state = true;
            }
        }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        

    }

    public void SSStart()
    {
        foreach (string i in story.Split())//loop original story
        {
            s.Add(i);
            if (i.StartsWith("["))
            {
                w.Add(i);
            }
        }
        foreach (string j in w)//loop through what input to get, noun,verb
        {
            input.text = "Enter a " + j;
            if (Input.GetKeyDown("return")) {
                inputed.Add(input.text);
            }
        }
        foreach (string h in s)//loop to put the story together
        {
            if (h.StartsWith("["))
            {
                Finish1 = inputed[count];
                count++;
            }
            else
            {
                Finish1 = h;
            }
            Finish += Finish1 + "";
        }
        word.text = Finish;
    }
}
