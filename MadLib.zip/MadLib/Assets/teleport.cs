﻿using UnityEngine;
public class script : MonoBehaviour
{
    public Vector3 des;

    void OnTriggerEnter(Collider other)
    {
        other.attachedRigidbody.transform.position = des;//ridgid body is the character or something that bump into it
    }
}
