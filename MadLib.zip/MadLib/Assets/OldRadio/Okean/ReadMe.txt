================Old radio "Ocean"===============
Requires Unity 5.5.0 or higher.

This pack includes model of old transistor radio receiver. 


ilonion32@gmail.com
"IL.ranch", 2016-8.