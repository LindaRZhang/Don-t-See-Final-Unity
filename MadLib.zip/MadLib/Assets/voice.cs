﻿using UnityEngine;
using UnityEngine.Windows.Speech;
using System.Linq;
using System;
using System.Collections.Generic;

public class voice : MonoBehaviour
{
    public Transform t;
    private KeywordRecognizer key;
    string story1 = "";
    private Dictionary<string, Action> actions = new Dictionary<string, Action>();
    private object myGameObject;
    private object madlib;

    private void Start()
    {
        actions.Add("foward",foward);//add word to dict and then call function if they hear that word "foward"
        actions.Add("back", back);
        actions.Add("left", left);
        actions.Add("right", right);
        //actions.Add("start", madlib().SSStart());


        key = new KeywordRecognizer(actions.Keys.ToArray());//object
        key.OnPhraseRecognized += Recgon;//when OnPhraseRecognize event occur it will call function Recgon
        key.Start(); //start picking up voice
    }

    private void Recgon(PhraseRecognizedEventArgs speech)//recognize speech
    {
        Debug.Log(speech.text);
        actions[speech.text].Invoke();//pass the speech in 
    }
    private void foward()
    {
        t.Translate(0, 0, 2);
    }
    private void back()
    {
        t.Translate(0, 0, -2);
    }
    private void left()
    {
        t.Translate(-2, 0, 0);
    }
    private void right()
    {
        t.Translate(2, 0, 0);
    }
}
